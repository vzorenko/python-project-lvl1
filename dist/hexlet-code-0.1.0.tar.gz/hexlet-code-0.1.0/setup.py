# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '\xd0\x9f\xd1\x80\xd0\xbe\xd0\xb5\xd0\xba\xd1\x82 \xd0\xb8\xd0\xb3\xd1\x80\xd1\x8b \xd1\x80\xd0\xb0\xd0\xb7\xd1\x83\xd0\xbc\xd0\xb0',
    'long_description': None,
    'author': 'Vasiliy',
    'author_email': 'services@zorenko.info',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
}


setup(**setup_kwargs)
