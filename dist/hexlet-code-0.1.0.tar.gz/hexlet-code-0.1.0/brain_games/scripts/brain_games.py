#!/usr/bin/env python




def wellcome():
    print('Welcome to the Brain Games!')

def main():
    wellcome()


if __name__ == '__main__':
    main()